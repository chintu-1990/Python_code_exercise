/**
Copyright (c)  2012 - 2013 Intel Corporation. All rights reserved
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Intel Corporation.

@file:
  XmlCli.h

@brief:
  Definitions for XML CLI interface/Wrapper
**/

#ifndef _XMLCLI_MODULE_H
#define _XMLCLI_MODULE_H

#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/ShellCEntryLib.h>
#include <Library/ShellLib.h>
#include <Library/IoLib.h>
#include <Library/BaseMemoryLib.h>

//#include <Protocol/EfiShell.h>
//#include <Library/UefiBootServicesTableLib.h>
#include <Protocol/SimpleFileSystem.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/FileHandleLib.h>


// header signature
#define SHARED_MB_BIOS_SIG              0xBA5EBA11
#define LEG_MAILBOX_SIG                 0x5A7ECAFE
#define CLI_REQ_SIG                     0xCA11AB1E
#define CLI_RES_SIG                     0xCA11B0B0

#define CLI_REQ_READY_SIG               0xC001C001
#define CLI_RES_READY_SIG               0xCAFECAFE


#define GBT_XML_ADDR_OFF                0x0C
#define SETUP_KNOBS_ADDR_OFF            0x3C
#define SETUP_KNOBS_SIZE_OFF            0x40

#define CLI_SGN_RESPONCE_READY          0xCAFECAFE
#define CLI_SGN_REQUEST_READY           0xC001C001

#define APPEND_BIOS_KNOBS_OPCODE        0x0048
#define RESTOREMODIFY_KNOBS_OPCODE      0x0049
#define READ_BIOS_KNOBS_OPCODE          0x004A
#define LOAD_DEFAULT_KNOBS_OPCODE       0x004B

#define CMOS_DRAM_SHARED_MAILBOX_ADDR_REG   0xF0    // 2 bytes CMOS Space for the DRAM Share Mailbox address [31:16]
#define SW_XML_CLI_ENTRY                    0xF6
#define SW_SMI_PORT                         0xB2

#define BIOS_KNOB_START_TAG             0x626F6E6B3C        // "<knob"
#define BIOS_KNOB_START_TAG_MASK        0xFFFFFFFFFF
#define BIOS_KNOB_START_TAG_SIZE        0x5

#define BIOS_KNOB_END_TAG_1             0x3E2F              // "/>"
#define BIOS_KNOB_END_TAG_1_MASK        0xFFFF
#define BIOS_KNOB_END_TAG_1_SIZE        0x2

#define BIOS_KNOB_END_TAG_2             0x3E626F6E6B2F3C    // "</knob>"
#define BIOS_KNOB_END_TAG_2_MASK        0xFFFFFFFFFFFFFF
#define BIOS_KNOB_END_TAG_2_SIZE        0x7

#define BIOS_KNOB_NAME_TAG              0x223D656D616E      // 'name="'
#define BIOS_KNOB_NAME_TAG_MASK         0xFFFFFFFFFFFF
#define BIOS_KNOB_NAME_TAG_SIZE         0x6

#define BIOS_KNOB_VARDID_TAG_1          0x65726F7473726176  // 'varstore'
#define BIOS_KNOB_VARDID_TAG_1_SIZE     0x8
#define BIOS_KNOB_VARDID_TAG_2          0x223D7865646E49    // 'Index="'
#define BIOS_KNOB_VARDID_TAG_2_MASK     0xFFFFFFFFFFFFFF
#define BIOS_KNOB_VARDID_TAG_2_SIZE     0x7

#define BIOS_KNOB_SIZE_TAG              0x223D657A6973      // 'size="'
#define BIOS_KNOB_SIZE_TAG_MASK         0xFFFFFFFFFFFF
#define BIOS_KNOB_SIZE_TAG_SIZE         0x6

#define BIOS_KNOB_OFFSET_TAG            0x223D74657366666F  // 'offset="'
#define BIOS_KNOB_OFFSET_TAG_MASK       0xFFFFFFFFFFFFFFFF
#define BIOS_KNOB_OFFSET_TAG_SIZE       0x8

#define BIOS_KNOB_ATTR_END              0x22                // '"'

#pragma pack(1)

typedef struct _KNOB_INPUT_DATA {
  CHAR8   ReqKnobName[64];
  UINT64  ReqKnobValue;
  BOOLEAN KnobFoundInXml;
  UINT8   KnobVarId;
  UINT16  KnobOffset;
  UINT8   KnobSize;
  UINT64  DefKnobValue;
  UINT64  CurrKnobValue;
  BOOLEAN KnobProcByCli;
  BOOLEAN InvalidInputKnobVal;
} KNOB_INPUT_DATA;

typedef struct _XML_CLI_DATA {
  UINT32  DramMbAddress;
  UINT32  GbtXmlAddress;
  UINT32  XmlSize;
  UINT32  CliReqBuff;
  UINT32  CliResBuff;
  UINT32  SetupKnobAddr;
  UINT32  SetupKnobSize;
  UINT16  CommandId;
  UINT16  ReqKnobEntries;
  UINT16  ReqKnobValidEntries;
  UINT16  ReqKnobEntriesProcessed;
} XML_CLI_DATA;

typedef struct SharedMemoryHeaderEntry_ {
  UINT32  BIOS_Signature;
  union {
    struct {
      UINT32  EntriesNumber : 8;
      UINT32  FirstEntryOffset : 8;
      UINT32  EntrySize : 8;
      UINT32  ReservedByte : 7;
      UINT32  ValidHeader : 1;
    } EntriesInfo;
  } _u1;
  UINT32  BIOS_Signature2;
  UINT32  CheckSum;
  struct {
    UINT32  Reserved0 : 8;
    UINT32  DeviceID : 16;
    UINT32  BAR : 4;
    UINT32  Reserved1 : 4;
  } CommonFlags;
  struct {
    UINT32  MinorVersion : 8;
    UINT32  MajorVersion : 16;
    UINT32  ReleaseVersion : 4;
    UINT32  Reserved : 4;
  } CliSpecVersion;
  UINT32  Reserved[2];
} SharedMemoryHeaderEntry;

typedef struct SharedMemoryEntry_ {
  UINT32  Signature;
  UINT32  Offset;
  UINT32  Size;
  union {
    struct {
      UINT32  AccessType : 3;
      UINT32  ReservedType : 5;
      UINT32  DeviceID : 16;
      UINT32  BAR : 4;
      UINT32  ReservedBit : 4;
    } Flags;
    UINT32  flatFlags;
  } _u2;
} SharedMemoryEntry;

#define SHARED_MEM_MAX_ENTRY_NUMBER  10

typedef struct SharedMemoryTable_ {
  SharedMemoryHeaderEntry Header;
  SharedMemoryEntry       Entry[SHARED_MEM_MAX_ENTRY_NUMBER + 1];  // one entry for terminator 0xDEADBEA7
} SharedMemoryTable;

typedef union {
  UINT16  rawAccess;
  struct {
    UINT16    wrongParameter      :1;
    UINT16    CannotExecute       :1;
    UINT16    commandSideEffects  :4;
    UINT16    Reserved            :10;
  } fields;
} CLI_BUFFER_FLAGS;

typedef struct {
  UINT32              signature;
  UINT16              commandID;
  CLI_BUFFER_FLAGS    flags;
  UINT32              status;
  UINT32              parametersSize;
//  UINT8             parameters[0];
} CLI_BUFFER;

typedef struct {
  UINT8   varstoreIndex;
  UINT16  KnobOffset;
  UINT8   KnobSize;
//  UINT8   KnobValue[KnobSize];
} CLI_PROCESS_BIOS_KNOBS_RQST_PARAM;

typedef struct {
  UINT32  KnobXmlEntryPtr;
  UINT16  KnobXmlEntrySize;
  UINT8   varstoreIndex;
  UINT16  KnobOffset;
  UINT8   KnobSize;
//  UINT8   KnobDefValue[KnobSize];
//  UINT8   KnobCurrValue[KnobSize];
} CLI_PROCESS_BIOS_KNOBS_RSP_PARAM;

#pragma pack()

#endif //_XMLCLI_MODULE_H
